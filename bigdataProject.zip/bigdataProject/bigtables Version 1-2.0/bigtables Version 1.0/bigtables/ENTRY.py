import sqlite3
##conn = sqlite3.connect('todo.db') # Warning: This file is created in the current directory
##conn.execute("CREATE TABLE todo (id INTEGER PRIMARY KEY, task char(100) NOT NULL, status bool NOT NULL)")
##conn.execute("INSERT INTO todo (task,status) VALUES ('Read A-byte-of-python to get a good introduction into Python',1)")
##conn.execute("INSERT INTO todo (task,status) VALUES ('Visit the Python website',0)")
##conn.execute("INSERT INTO todo (task,status) VALUES ('Test various editors for and check the syntax highlighting',0)")
##conn.execute("INSERT INTO todo (task,status) VALUES ('Choose your favorite WSGI-Framework',1)")
##conn.commit()

conn = sqlite3.connect('NewsChannel.db') # Warning: This file is created in the current directory
conn.execute("CREATE TABLE IF NOT EXISTS NewsChannel(Id INTEGER PRIMARY KEY, NewsChannelName char(100) NOT NULL)")
conn.execute("INSERT INTO NewsChannel (NewsChannelName) VALUES ('BBC')")
conn.execute("INSERT INTO NewsChannel (NewsChannelName) VALUES ('CBC')")
conn.execute("INSERT INTO NewsChannel (NewsChannelName) VALUES ('CNN')")
conn.execute("INSERT INTO NewsChannel (NewsChannelName) VALUES ('EVERYDAY')")
conn.execute("INSERT INTO NewsChannel (NewsChannelName) VALUES ('FOXNEWS')")
conn.execute("INSERT INTO NewsChannel (NewsChannelName) VALUES ('GDN')")
conn.execute("INSERT INTO NewsChannel (NewsChannelName) VALUES ('GOOD')")
conn.execute("INSERT INTO NewsChannel (NewsChannelName) VALUES ('KAISERHEALTH')")
conn.execute("INSERT INTO NewsChannel (NewsChannelName) VALUES ('MSN')")
conn.execute("INSERT INTO NewsChannel (NewsChannelName) VALUES ('NBC')")
conn.execute("INSERT INTO NewsChannel (NewsChannelName) VALUES ('NPR')")
conn.execute("INSERT INTO NewsChannel (NewsChannelName) VALUES ('NYTIMES')")
conn.execute("INSERT INTO NewsChannel (NewsChannelName) VALUES ('REUTERS')")
conn.execute("INSERT INTO NewsChannel (NewsChannelName) VALUES ('USNEWS')")
conn.execute("INSERT INTO NewsChannel (NewsChannelName) VALUES ('WSJ')")

conn.execute("CREATE TABLE IF NOT EXISTS BBC (Id INTEGER PRIMARY KEY, TwitterId char(100) NOT NULL, DateTime char(200) NOT NULL, TwitterText char(500) NOT NULL)")
conn.execute("CREATE TABLE IF NOT EXISTS CBC (Id INTEGER PRIMARY KEY, TwitterId char(100) NOT NULL, DateTime char(200) NOT NULL, TwitterText char(500) NOT NULL)")
conn.execute("CREATE TABLE IF NOT EXISTS CNN (Id INTEGER PRIMARY KEY, TwitterId char(100) NOT NULL, DateTime char(200) NOT NULL, TwitterText char(500) NOT NULL)")
conn.execute("CREATE TABLE IF NOT EXISTS EVERYDAY (Id INTEGER PRIMARY KEY, TwitterId char(100) NOT NULL, DateTime char(200) NOT NULL, TwitterText char(500) NOT NULL)")
conn.execute("CREATE TABLE IF NOT EXISTS FOXNEWS (Id INTEGER PRIMARY KEY, TwitterId char(100) NOT NULL, DateTime char(200) NOT NULL, TwitterText char(500) NOT NULL)")
conn.execute("CREATE TABLE IF NOT EXISTS GDN (Id INTEGER PRIMARY KEY, TwitterId char(100) NOT NULL, DateTime char(200) NOT NULL, TwitterText char(500) NOT NULL)")
conn.execute("CREATE TABLE IF NOT EXISTS GOOD (Id INTEGER PRIMARY KEY, TwitterId char(100) NOT NULL, DateTime char(200) NOT NULL, TwitterText char(500) NOT NULL)")
conn.execute("CREATE TABLE IF NOT EXISTS KAISERHEALTH (Id INTEGER PRIMARY KEY, TwitterId char(100) NOT NULL, DateTime char(200) NOT NULL, TwitterText char(500) NOT NULL)")
conn.execute("CREATE TABLE IF NOT EXISTS LATIMES (Id INTEGER PRIMARY KEY, TwitterId char(100) NOT NULL, DateTime char(200) NOT NULL, TwitterText char(500) NOT NULL)")
conn.execute("CREATE TABLE IF NOT EXISTS MSN (Id INTEGER PRIMARY KEY, TwitterId char(100) NOT NULL, DateTime char(200) NOT NULL, TwitterText char(500) NOT NULL)")
conn.execute("CREATE TABLE IF NOT EXISTS NPR (Id INTEGER PRIMARY KEY, TwitterId char(100) NOT NULL, DateTime char(200) NOT NULL, TwitterText char(500) NOT NULL)")
conn.execute("CREATE TABLE IF NOT EXISTS NYTIMES (Id INTEGER PRIMARY KEY, TwitterId char(100) NOT NULL, DateTime char(200) NOT NULL, TwitterText char(500) NOT NULL)")
conn.execute("CREATE TABLE IF NOT EXISTS REUTERS (Id INTEGER PRIMARY KEY, TwitterId char(100) NOT NULL, DateTime char(200) NOT NULL, TwitterText char(500) NOT NULL)")
conn.execute("CREATE TABLE IF NOT EXISTS NBC (Id INTEGER PRIMARY KEY, TwitterId char(100) NOT NULL, DateTime char(200) NOT NULL, TwitterText char(500) NOT NULL)")
conn.execute("CREATE TABLE IF NOT EXISTS USNEWS (Id INTEGER PRIMARY KEY, TwitterId char(100) NOT NULL, DateTime char(200) NOT NULL, TwitterText char(500) NOT NULL)")
conn.execute("CREATE TABLE IF NOT EXISTS WSJ (Id INTEGER PRIMARY KEY, TwitterId char(100) NOT NULL, DateTime char(200) NOT NULL, TwitterText char(500) NOT NULL)")

conn.execute("create index NewsChannel_ID_INDEX on NewsChannel(NewsChannelName);")
conn.execute("create index BBC_TwitterText_INDEX on BBC(TwitterText);")
conn.execute("create index CBC_TwitterText_INDEX on CBC(TwitterText);")
conn.execute("create index CNN_TwitterText_INDEX on CNN(TwitterText);")
conn.execute("create index EVERYDAY_TwitterText_INDEX on EVERYDAY(TwitterText);")
conn.execute("create index FOXNEWS_TwitterText_INDEX on FOXNEWS(TwitterText);")
conn.execute("create index GDN_TwitterText_INDEX on GDN(TwitterText);")
conn.execute("create index GOOD_TwitterText_INDEX on GOOD(TwitterText);")
conn.execute("create index KAISERHEALTH_TwitterText_INDEX on KAISERHEALTH(TwitterText);")
conn.execute("create index MSN_TwitterText_INDEX on MSN(TwitterText);")
conn.execute("create index NBC_TwitterText_INDEX on NBC(TwitterText);")
conn.execute("create index NPR_TwitterText_INDEX on NPR(TwitterText);")
conn.execute("create index NYTIMES_TwitterText_INDEX on NYTIMES(TwitterText);")
conn.execute("create index REUTERS_TwitterText_INDEX on REUTERS(TwitterText);")
conn.execute("create index USNEWS_TwitterText_INDEX on USNEWS(TwitterText);")
conn.execute("create index WSJ_TwitterText_INDEX on WSJ(TwitterText);")

with open("/Users/venne/Desktop/todo/Health-Tweets/bbchealth.txt", "r") as f:
    primary_key = 0
    for line in f:
        data = line.split("|")
        conn.execute("INSERT INTO BBC (TwitterId, DateTime, TwitterText) VALUES (?, ?, ?);",((data[0],data[1],data[2])))
        
with open("/Users/venne/Desktop/todo/Health-Tweets/cbchealth.txt", "r") as f:
    primary_key = 0
    for line in f:
        data = line.split("|")
        conn.execute("INSERT INTO CBC (TwitterId, DateTime, TwitterText) VALUES (?, ?, ?);",((data[0],data[1],data[2])))

with open("/Users/venne/Desktop/todo/Health-Tweets/cnnhealth.txt", encoding="utf8") as f:
    primary_key = 0
    for line in f:
        data = line.split("|")
        conn.execute("INSERT INTO CNN (TwitterId, DateTime, TwitterText) VALUES (?, ?, ?);",((data[0],data[1],data[2])))

with open("/Users/venne/Desktop/todo/Health-Tweets/everydayhealth.txt", encoding="utf8") as f:
    primary_key = 0
    for line in f:
       data = line.split("|")
       conn.execute("INSERT INTO EVERYDAY (TwitterId, DateTime, TwitterText) VALUES (?, ?, ?);",((data[0],data[1],data[2])))

with open("/Users/venne/Desktop/todo/Health-Tweets/foxnewshealth.txt", encoding='cp1252') as f:
    primary_key = 0
    for line in f:
        data = line.split("|")
        conn.execute("INSERT INTO FOXNEWS (TwitterId, DateTime, TwitterText) VALUES (?, ?, ?);",((data[0],data[1],data[2])))

with open("/Users/venne/Desktop/todo/Health-Tweets/gdnhealthcare.txt", encoding="utf8") as f:
    primary_key = 0
    for line in f:
        data = line.split("|")
        conn.execute("INSERT INTO GDN (TwitterId, DateTime, TwitterText) VALUES (?, ?, ?);",((data[0],data[1],data[2])))

with open("/Users/venne/Desktop/todo/Health-Tweets/goodhealth.txt", encoding="utf8") as f:
  primary_key = 0
  for line in f:
      data = line.split("|")
      conn.execute("INSERT INTO GOOD (TwitterId, DateTime, TwitterText) VALUES (?, ?, ?);",((data[0],data[1],data[2])))

with open("/Users/venne/Desktop/todo/Health-Tweets/KaiserHealthNews.txt",  encoding='cp1252') as f:
    primary_key = 0
    for line in f:
        data = line.split("|")
        conn.execute("INSERT INTO KAISERHEALTH (TwitterId, DateTime, TwitterText) VALUES (?, ?, ?);",((data[0],data[1],data[2])))

with open("/Users/venne/Desktop/todo/Health-Tweets/latimeshealth.txt", encoding="utf8") as f:
    primary_key = 0
    for line in f:
        data = line.split("|")
        conn.execute("INSERT INTO LATIMES (TwitterId, DateTime, TwitterText) VALUES (?, ?, ?);",((data[0],data[1],data[2])))

with open("/Users/venne/Desktop/todo/Health-Tweets/msnhealthnews.txt",  encoding='cp1252') as f:
    primary_key = 0
    for line in f:
        data = line.split("|")
        conn.execute("INSERT INTO MSN (TwitterId, DateTime, TwitterText) VALUES (?, ?, ?);",((data[0],data[1],data[2])))

with open("/Users/venne/Desktop/todo/Health-Tweets/NBChealth.txt",  encoding='cp1252' ) as f:
    primary_key = 0
    for line in f:
        data = line.split("|")
        conn.execute("INSERT INTO NBC (TwitterId, DateTime, TwitterText) VALUES (?, ?, ?);",((data[0],data[1],data[2])))

with open("/Users/venne/Desktop/todo/Health-Tweets/nprhealth.txt", encoding="utf8") as f:
    primary_key = 0
    for line in f:
        data = line.split("|")
        conn.execute("INSERT INTO NPR (TwitterId, DateTime, TwitterText) VALUES (?, ?, ?);",((data[0],data[1],data[2])))

with open("/Users/venne/Desktop/todo/Health-Tweets/nytimeshealth.txt", encoding="utf8") as f:
    primary_key = 0
    for line in f:
        data = line.split("|")
        conn.execute("INSERT INTO NYTIMES (TwitterId, DateTime, TwitterText) VALUES (?, ?, ?);",((data[0],data[1],data[2])))

with open("/Users/venne/Desktop/todo/Health-Tweets/reuters_health.txt", encoding="utf8") as f:
    primary_key = 0
    for line in f:
        data = line.split("|")
        conn.execute("INSERT INTO REUTERS (TwitterId, DateTime, TwitterText) VALUES (?, ?, ?);",((data[0],data[1],data[2])))

with open("/Users/venne/Desktop/todo/Health-Tweets/usnewshealth.txt", encoding="utf8") as f:
    primary_key = 0
    for line in f:
        data = line.split("|")
        conn.execute("INSERT INTO USNEWS (TwitterId, DateTime, TwitterText) VALUES (?, ?, ?);",((data[0],data[1],data[2])))

with open("/Users/venne/Desktop/todo/Health-Tweets/wsjhealth.txt",  encoding='cp1252') as f:
    primary_key = 0
    for line in f:
        data = line.split("|")
        conn.execute("INSERT INTO WSJ (TwitterId, DateTime, TwitterText) VALUES (?, ?, ?);",((data[0],data[1],data[2])))
        
conn.commit()


