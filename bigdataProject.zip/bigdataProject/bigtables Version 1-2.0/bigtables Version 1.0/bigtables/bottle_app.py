import sqlite3
from textblob import TextBlob
from bottle import route, run, debug, template, request
import bottle

@route('/', method='GET')
@route('/todo', method='GET')
def todo_list():
    #Connecting database to get news channel names
    conn = sqlite3.connect('NewsChannel.db')
    c = conn.cursor()
    c.execute("SELECT NewsChannelName FROM NewsChannel")
    result = c.fetchall()

    #Get all the form items. 'years' is a list containing selected years by the user
    channel = request.query.channel
    keyword = request.query.form
    years = request.GET.getall('year')

    #if year is not mentioned all the tweets from all the years will be displayed
    if len(years) == 0:
        #for the first loading of website channel will be empty
        if channel == '':
            return template('make_table', rows2=[],rows=result,tabs = [], posPer=0,negPer=0,neutralPer=0,pos=0,neg=0,neut=0)
        
        years = ['2011','2012','2013','2014','2015']
        return calculatePolarity(channel,years,keyword,c,result)
    else:
        return calculatePolarity(channel,years,keyword,c,result)    

debug(True)

def calculatePolarity(channel,years,keyword,c,result):
    listYear=[]
    tabList = []
    countPos = countNeg = countNeutral = 0
    positiveCount = 0
    negativeCount = 0
    neutralCount = 0
    posPercent = 0
    negPercent = 0
    neutralPercent = 0
    
    for year in years:
        c.execute("SELECT substr(DateTime,26) as year,TwitterText FROM " + channel + " where DateTime like ? and TwitterText like ?", (('%'+year+'%'), ('%'+keyword+'%')))
        tab = c.fetchall()
        tabList.extend(tab)
        for tweet in tab:
            analysis = TextBlob(tweet[1])

            #Please do not use same name as the name in modules (example : sentiment)
            sentiment = analysis.sentiment.polarity
            
            #This indicates positive polarity
            if sentiment > 0.0:
                countPos += 1
            #This indicates neutral polarity
            elif sentiment == 0.0:
                countNeutral += 1
            #Less than zero indicates negative polarity
            else:
                countNeg += 1
            
        listYear.append([year,countPos,countNeutral,countNeg])
        positiveCount = positiveCount + countPos
        negativeCount = negativeCount + countNeg
        neutralCount = neutralCount + countNeutral
        
        #Making all sentiments to zero so that sentiments will be calulated from fresh in the next 'year' in the 'years' list
        countPos = countNeg = countNeutral = 0
        totalCount = positiveCount + negativeCount +  neutralCount
        
        if(positiveCount > 0):
            posPercent = round((positiveCount * 100)/(totalCount),2)
        
        if(negativeCount > 0):
            negPercent = round((negativeCount * 100)/(totalCount),2)
        
        if(neutralCount > 0):
            neutralPercent = round((neutralCount * 100)/(totalCount),2)
        
    return template('make_table',rows2=listYear,rows=result,tabs = tabList,pos=positiveCount,neg=negativeCount,neut=neutralCount,posPer=posPercent,negPer=negPercent,neutralPer=neutralPercent)
    
run(host='localhost', port=8080)
